import * as React from 'react';
import { FormDefinition } from '../models/FormDefinition';
import CifLookup from '../cifLookup/components/CifLookup';

export interface IFormRendererProps {
  definition: FormDefinition;
  formData: any;
  onChange: (name: string, value: any) => void;
  onAction: (action: string) => void;
  onLoadingChange?: (loading: boolean) => void;
  onError?: (error: string | null) => void;
}

export default class FormRenderer extends React.Component<IFormRendererProps, {}> {
  private renderField = (field) => {
    const value = this.props.formData[field.name] || '';
    return (
      <div key={field.name} style={{ marginBottom: 10 }}>
        <label>{field.label}</label>
        <input
          type={field.type === 'number' ? 'number' : 'text'}
          value={value}
          onChange={(e) => this.props.onChange(field.name, e.target.value)}
          readOnly={this.props.definition.isReadOnly || field.readonly}
        />
      </div>
    );
  };

  public render() {
    const { definition } = this.props;

    return (
      <div>
        <h2>Dynamic Form</h2>
        {definition.fields.map(field => {
          if (field.name === 'CIF') {
            return (
              <div key={field.name}>
                <CifLookup
                  onCustomerLoaded={(customer) => {
                    this.props.onChange('CIF', customer.CIF);
                    this.props.onChange('CustomerName', customer.Name);
                    this.props.onChange('CustomerType', customer.Type);
                    this.props.onChange('Amount', customer.RequestAmount);
                  }}
                  onError={(err) => this.props.onError && this.props.onError(err)}
                  onLoadingChange={(isLoading) => this.props.onLoadingChange && this.props.onLoadingChange(isLoading)}
                />
              </div>
            );
          }
          return this.renderField(field);
        })}
        <div style={{ marginTop: 20 }}>
          {definition.actions.map(action => (
            <button key={action.label} onClick={() => this.props.onAction(action.label)}>
              {action.label}
            </button>
          ))}
        </div>
      </div>
    );
  }
}
