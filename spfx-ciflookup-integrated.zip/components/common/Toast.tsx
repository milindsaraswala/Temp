import * as React from 'react';

export const Toast = ({ message, type = 'error' }) => {
  const style = {
    padding: '10px 15px',
    backgroundColor: type === 'error' ? '#f44336' : '#4caf50',
    color: 'white',
    borderRadius: 4,
    margin: '10px 0'
  };
  return <div style={style}>{message}</div>;
};
