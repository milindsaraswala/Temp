import * as React from 'react';
import FormRenderer from './components/FormRenderer';
import { LoadingOverlay } from './components/common/LoadingOverlay';
import { Toast } from './components/common/Toast';

export default class BpmForm extends React.Component<{}, any> {
  constructor(props: {}) {
    super(props);
    this.state = {
      formData: {},
      loading: false,
      error: null,
      definition: {
        formId: 0,
        templateId: 101,
        currentStage: null,
        userRole: "Initiator",
        isReadOnly: false,
        fields: [
          { name: "CIF", type: "text", label: "CIF Number", required: true },
          { name: "CustomerName", type: "text", label: "Customer Name", readonly: true },
          { name: "CustomerType", type: "text", label: "Customer Type", readonly: true },
          { name: "Amount", type: "number", label: "Requested Amount", readonly: true }
        ],
        sections: [],
        actions: [
          { label: "Submit", visibleWhen: "userRole == 'Initiator' && currentStage == null" }
        ]
      }
    };
  }

  handleChange = (name, value) => {
    this.setState(prev => ({
      formData: {
        ...prev.formData,
        [name]: value
      }
    }));
  };

  handleAction = (action) => {
    alert('Action: ' + action);
  };

  render() {
    const { definition, formData, loading, error } = this.state;

    return (
      <div>
        {loading && <LoadingOverlay />}
        {error && <Toast message={error} type="error" />}
        <FormRenderer
          definition={definition}
          formData={formData}
          onChange={this.handleChange}
          onAction={this.handleAction}
          onLoadingChange={(loading) => this.setState({ loading })}
          onError={(error) => this.setState({ error })}
        />
      </div>
    );
  }
}
