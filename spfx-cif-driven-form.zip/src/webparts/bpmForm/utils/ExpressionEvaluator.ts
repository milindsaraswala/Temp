export default function ExpressionEvaluator(expr: string, context: any): boolean {
  try {
    const keys = Object.keys(context);
    const values = Object.values(context);
    const fn = new Function(...keys, \`return (\${expr});\`);
    return fn(...values);
  } catch (e) {
    console.warn("Invalid expression:", expr);
    return false;
  }
}
