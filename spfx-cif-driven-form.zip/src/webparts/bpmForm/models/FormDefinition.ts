export interface FieldDefinition {
  name: string;
  label: string;
  type: string;
  required?: boolean;
  readonly?: boolean;
}

export interface SectionDefinition {
  name: string;
  label: string;
  visibleWhen: string;
}

export interface ActionButtonDefinition {
  label: string;
  visibleWhen: string;
}

export interface FormDefinition {
  formId: number;
  templateId: number;
  currentStage: string | null;
  userRole: string;
  isReadOnly: boolean;
  fields: FieldDefinition[];
  sections: SectionDefinition[];
  actions: ActionButtonDefinition[];
  initialValues?: { [key: string]: any };
}
