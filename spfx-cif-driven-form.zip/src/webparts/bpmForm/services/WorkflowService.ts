export default class WorkflowService {
  public async getFormDefinition(formId: number): Promise<any> {
    // mock data for testing
    return fetch('/models/sampleFormDefinition.json').then(res => res.json());
  }

  public async performAction(formId: number, action: string, formData: any): Promise<void> {
    console.log('Performing action:', action, 'for form:', formId, 'with data:', formData);
  }
}
