
namespace WorkflowEngine.Core.Models;
public class Task
{
    public int Id { get; set; }
    public int InstanceId { get; set; }
    public int StageId { get; set; }
    public string Status { get; set; } = "Pending";
    public DateTime? DueDate { get; set; }
}
