
namespace WorkflowEngine.Core.Models;
public class Transition
{
    public int Id { get; set; }
    public int WorkflowDefinitionId { get; set; }
    public int FromStageId { get; set; }
    public int ToStageId { get; set; }
    public string ActionName { get; set; } = "";
}
