
namespace WorkflowEngine.Core.Models;
public class Stage
{
    public int Id { get; set; }
    public int WorkflowDefinitionId { get; set; }
    public string Name { get; set; } = "";
    public int? RoleId { get; set; }
    public bool IsInitial { get; set; } = false;
    public bool IsFinal { get; set; } = false;
    public int? SlaHours { get; set; }
}
