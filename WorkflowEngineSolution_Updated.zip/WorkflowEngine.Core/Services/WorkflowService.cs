
using WorkflowEngine.Core.Interfaces;
using WorkflowEngine.Core.Models;
using WorkflowEngine.Data.Repositories;

namespace WorkflowEngine.Core.Services;

public class WorkflowService : IWorkflowService
{
    private readonly IWorkflowRepository _workflowRepository;

    public WorkflowService(IWorkflowRepository workflowRepository)
    {
        _workflowRepository = workflowRepository;
    }

    public async Task<WorkflowDefinition?> GetWorkflowDefinitionAsync(int id)
    {
        return await _workflowRepository.GetByIdAsync(id);
    }

    public async Task<IEnumerable<Stage>> GetStagesByWorkflowIdAsync(int workflowDefinitionId)
    {
        return await _workflowRepository.GetStagesAsync(workflowDefinitionId);
    }

    public async Task MoveToNextStageAsync(int instanceId, string action)
    {
        // Fetch workflow instance, current stage and validate transition
        var transition = await _workflowRepository.GetTransitionAsync(instanceId, action);
        if (transition == null)
            throw new InvalidOperationException("Invalid transition");

        // Business logic for moving to the next stage would go here
        // For simplicity, it's left as a placeholder
    }
}
