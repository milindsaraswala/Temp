
using Microsoft.EntityFrameworkCore;
using WorkflowEngine.Core.Models;

namespace WorkflowEngine.Data.DbContexts;
public class WorkflowDbContext : DbContext
{
    public WorkflowDbContext(DbContextOptions<WorkflowDbContext> options) : base(options) { }

    public DbSet<WorkflowDefinition> WorkflowDefinitions => Set<WorkflowDefinition>();
    public DbSet<Stage> Stages => Set<Stage>();
    public DbSet<Transition> Transitions => Set<Transition>();
    public DbSet<Task> Tasks => Set<Task>();
}
