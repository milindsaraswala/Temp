
using WorkflowEngine.Core.Models;
namespace WorkflowEngine.Data.Repositories;
public interface IWorkflowRepository
{
    Task<WorkflowDefinition?> GetByIdAsync(int id);
    Task<IEnumerable<Stage>> GetStagesAsync(int workflowDefinitionId);
    Task<Transition?> GetTransitionAsync(int fromStageId, string actionName);
}
