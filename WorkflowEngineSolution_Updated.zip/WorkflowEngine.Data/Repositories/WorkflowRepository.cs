
using Microsoft.EntityFrameworkCore;
using WorkflowEngine.Core.Models;
using WorkflowEngine.Data.DbContexts;
namespace WorkflowEngine.Data.Repositories;
public class WorkflowRepository : IWorkflowRepository
{
    private readonly WorkflowDbContext _context;
    public WorkflowRepository(WorkflowDbContext context) => _context = context;

    public async Task<WorkflowDefinition?> GetByIdAsync(int id) =>
        await _context.WorkflowDefinitions.FindAsync(id);

    public async Task<IEnumerable<Stage>> GetStagesAsync(int workflowDefinitionId) =>
        await _context.Stages.Where(s => s.WorkflowDefinitionId == workflowDefinitionId).ToListAsync();

    public async Task<Transition?> GetTransitionAsync(int fromStageId, string actionName) =>
        await _context.Transitions.FirstOrDefaultAsync(t => t.FromStageId == fromStageId && t.ActionName == actionName);
}
