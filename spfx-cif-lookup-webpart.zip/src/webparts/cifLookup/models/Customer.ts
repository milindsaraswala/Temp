export interface Customer {
  CIF: string;
  Name: string;
  Type: string;
  Mobile: string;
  Nationality: string;
  Segment: string;
  RequestAmount: number;
}
