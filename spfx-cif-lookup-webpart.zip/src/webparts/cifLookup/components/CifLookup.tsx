import * as React from 'react';
import { Customer } from '../models/Customer';
import CifService from '../services/CifService';

export interface ICifLookupProps {
  onCustomerLoaded: (customer: Customer) => void;
}

export interface ICifLookupState {
  cif: string;
  customer: Customer | null;
  loading: boolean;
  error: string | null;
}

export default class CifLookup extends React.Component<ICifLookupProps, ICifLookupState> {
  private _cifService = new CifService();

  constructor(props: ICifLookupProps) {
    super(props);
    this.state = {
      cif: '',
      customer: null,
      loading: false,
      error: null
    };
  }

  private handleCifChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    this.setState({ cif: e.target.value });
  };

  private handleCifBlur = async () => {
    const { cif } = this.state;
    if (cif.length < 3) return;

    this.setState({ loading: true, error: null });

    try {
      const customer = await this._cifService.getCustomerByCIF(cif);
      this.setState({ customer, loading: false });
      this.props.onCustomerLoaded(customer);
    } catch (err) {
      this.setState({ customer: null, error: 'Customer not found', loading: false });
    }
  };

  public render() {
    const { customer, cif, loading, error } = this.state;

    return (
      <div style={{ marginBottom: 20 }}>
        <label>CIF Number</label>
        <input
          type="text"
          value={cif}
          onChange={this.handleCifChange}
          onBlur={this.handleCifBlur}
          style={{ width: 300 }}
        />
        {loading && <span style={{ marginLeft: 10 }}>Loading...</span>}
        {error && <div style={{ color: 'red' }}>{error}</div>}
        {customer && (
          <div style={{ marginTop: 10, padding: 10, border: '1px solid #ccc' }}>
            <div><strong>Name:</strong> {customer.Name}</div>
            <div><strong>Type:</strong> {customer.Type}</div>
            <div><strong>Mobile:</strong> {customer.Mobile}</div>
            <div><strong>Nationality:</strong> {customer.Nationality}</div>
            <div><strong>Segment:</strong> {customer.Segment}</div>
            <div><strong>Request Amount:</strong> {customer.RequestAmount}</div>
          </div>
        )}
      </div>
    );
  }
}
