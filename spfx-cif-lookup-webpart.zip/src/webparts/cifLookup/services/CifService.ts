import { Customer } from '../models/Customer';

export default class CifService {
  public async getCustomerByCIF(cif: string): Promise<Customer> {
    const response = await fetch(`/api/customer/${cif}`);
    if (!response.ok) throw new Error("Customer not found");
    return await response.json();
  }
}
