import * as React from 'react';
import CifLookup from '../cifLookup/components/CifLookup';

export default class CustomerOnboarding extends React.Component<{}, any> {
  constructor(props: {}, context: any) {
    super(props, context);
    this.state = {
      customer: null
    };
  }

  render() {
    return (
      <div>
        <h2>Customer Onboarding Form</h2>
        <CifLookup
          onCustomerLoaded={(customer) => this.setState({ customer })}
        />
        {this.state.customer && (
          <pre>{JSON.stringify(this.state.customer, null, 2)}</pre>
        )}
      </div>
    );
  }
}
