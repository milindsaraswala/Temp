import * as React from 'react';
import FormRenderer from './FormRenderer';
import { Toast } from './common/Toast';
import { LoadingOverlay } from './common/LoadingOverlay';
import { FormDefinition } from '../../models/FormDefinition';

export default class BpmForm extends React.Component<{}, any> {
  constructor(props: {}) {
    super(props);
    this.state = {
      formData: {},
      loading: false,
      error: null,
      definition: {
        formId: 0,
        templateId: 101,
        userRole: "Initiator",
        currentStage: null,
        isReadOnly: false,
        fields: [
          { name: "CIF", type: "text", label: "CIF Number", colSpan: 6 },
          { name: "CustomerName", type: "text", label: "Customer Name", colSpan: 12, importance: 'high' },
          { name: "CustomerType", type: "text", label: "Customer Type", colSpan: 6 },
          { name: "Amount", type: "number", label: "Requested Amount", colSpan: 6 }
        ],
        sections: [],
        actions: [
          { label: "Submit", visibleWhen: "userRole == 'Initiator' && currentStage == null" }
        ]
      }
    };
  }

  handleChange = (name, value) => {
    this.setState(prev => ({
      formData: { ...prev.formData, [name]: value }
    }));
  };

  handleAction = (action) => {
    alert('Action: ' + action);
  };

  render() {
    return (
      <div>
        {this.state.loading && <LoadingOverlay />}
        {this.state.error && <Toast message={this.state.error} />}
        <FormRenderer
          definition={this.state.definition}
          formData={this.state.formData}
          onChange={this.handleChange}
          onAction={this.handleAction}
          onLoadingChange={(loading) => this.setState({ loading })}
          onError={(error) => this.setState({ error })}
        />
      </div>
    );
  }
}
