import * as React from 'react';
import * as ReactDom from 'react-dom';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import BpmForm from './components/BpmForm';

export default class BpmFormWebPart extends BaseClientSideWebPart<{}> {
  public render(): void {
    const element = React.createElement(BpmForm, {});
    ReactDom.render(element, this.domElement);
  }
}
