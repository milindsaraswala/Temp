import * as React from 'react';
import FormRenderer from './FormRenderer/FormRenderer';
import { FormDefinition } from '../models/FormDefinition';

export interface IBpmFormState {
  formData: any;
  definition: FormDefinition;
  loading: boolean;
  error: string | null;
}

export default class BpmForm extends React.Component<{}, IBpmFormState> {
  constructor(props: {}) {
    super(props);
    this.state = {
      formData: {},
      loading: false,
      error: null,
      definition: {
        formId: 0,
        templateId: 101,
        currentStage: null,
        userRole: "Initiator",
        isReadOnly: false,
        fields: [
          { name: "CIF", type: "text", label: "CIF Number", required: true },
          { name: "CustomerName", type: "text", label: "Customer Name", readonly: true },
          { name: "CustomerType", type: "text", label: "Customer Type", readonly: true },
          { name: "Amount", type: "number", label: "Requested Amount", readonly: true }
        ],
        sections: [],
        actions: [
          { label: "Submit", visibleWhen: "userRole == 'Initiator' && currentStage == null" }
        ]
      }
    };
  }

  private handleChange = (name: string, value: any): void => {
    this.setState(prev => ({
      formData: {
        ...prev.formData,
        [name]: value
      }
    }));
  };

  private handleAction = (action: string): void => {
    alert('Action: ' + action);
  };

  public render() {
    const { definition, formData, loading, error } = this.state;

    return (
      <div>
        {loading && (
          <div style={{
            position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',
            backgroundColor: 'rgba(255,255,255,0.7)', display: 'flex',
            justifyContent: 'center', alignItems: 'center', zIndex: 9999
          }}>
            <div style={{
              border: '5px solid #ccc',
              borderTop: '5px solid #0078d4',
              borderRadius: '50%',
              width: '40px',
              height: '40px',
              animation: 'spin 1s linear infinite'
            }} />
          </div>
        )}

        {error && <div style={{ color: 'red', margin: 10 }}>{error}</div>}

        <FormRenderer
          definition={definition}
          formData={formData}
          onChange={this.handleChange}
          onAction={this.handleAction}
        />
      </div>
    );
  }
}
